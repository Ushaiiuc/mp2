# MP2 - Responsive Website Development

## Project
A simple student profile website built with HTML and Tailwind CSS.

## Features
- Navigation bar with section links
- Home, About, Skills and Contact sections
- Tailwind CSS styling
- Responsive layout for mobile and desktop
- Interactive navigation, buttons and hover effects

## How to run
1. Extract the ZIP file.
2. Open `index.html` in a web browser.
3. An internet connection is required to load Tailwind CSS from its CDN.

## Before submission
- Replace the sample profile text with your own details if you want.
- Create a GitHub repository and upload `index.html` and `README.md`.
- Submit the GitHub repository URL and this ZIP file.
